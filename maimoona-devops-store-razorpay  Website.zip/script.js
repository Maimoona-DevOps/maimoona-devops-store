const modal = document.getElementById('modal');
const toast = document.getElementById('toast');
const emailInput = document.getElementById('email');
let checkoutBusy = false;

function openProduct() {
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  setTimeout(() => emailInput?.focus(), 50);
}

function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
}

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function openCheckout() {
  const email = emailInput?.value.trim() || '';

  if (!validEmail(email)) {
    showToast('Please enter a valid email address.');
    emailInput?.focus();
    return;
  }

  if (checkoutBusy) return;
  checkoutBusy = true;
  showToast('Creating secure payment session…');

  try {
    const response = await fetch('/api/create-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product: 'aws-devops-roadmap-2026' })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.order_id || !data.key_id) {
      throw new Error(data.error || 'Could not create the payment order.');
    }

    if (!window.Razorpay) {
      throw new Error('Razorpay Checkout failed to load. Please refresh and try again.');
    }

    const options = {
      key: data.key_id,
      amount: data.amount,
      currency: data.currency,
      name: 'Maimoona DevOps',
      description: data.product || 'AWS DevOps Roadmap 2026',
      order_id: data.order_id,
      prefill: { email },
      theme: { color: '#ff9900' },
      handler: async function (payment) {
        await verifyPayment(payment);
      },
      modal: {
        ondismiss: function () {
          checkoutBusy = false;
          showToast('Payment window closed. No payment was confirmed.');
        }
      }
    };

    const checkout = new Razorpay(options);

    checkout.on('payment.failed', function (response) {
      checkoutBusy = false;
      const message = response?.error?.description || 'Payment failed. Please try again.';
      showToast(message);
    });

    checkout.open();
  } catch (error) {
    checkoutBusy = false;
    showToast(error.message || 'Something went wrong. Please try again.');
  }
}

async function verifyPayment(payment) {
  try {
    const response = await fetch('/api/verify-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        razorpay_order_id: payment.razorpay_order_id,
        razorpay_payment_id: payment.razorpay_payment_id,
        razorpay_signature: payment.razorpay_signature
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok || !data.verified) {
      throw new Error(data.error || 'Payment could not be verified.');
    }

    checkoutBusy = false;
    closeModal();
    showToast('Payment verified successfully 🎉');
    // Fulfillment is intentionally not automatic yet because no protected file delivery/storage is configured.
  } catch (error) {
    checkoutBusy = false;
    showToast(error.message || 'Payment verification failed. Please contact support.');
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => toast.classList.remove('show'), 4200);
}

document.addEventListener('click', (event) => {
  if (event.target === modal) closeModal();
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeModal();
});
