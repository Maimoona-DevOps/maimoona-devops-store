const Razorpay = require('razorpay');

const PRODUCT = {
  id: 'aws-devops-roadmap-2026',
  name: 'AWS DevOps Roadmap 2026',
  amount: 14900,
  currency: 'INR'
};

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    return res.status(500).json({ error: 'Razorpay server configuration is missing.' });
  }

  try {
    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET
    });

    // Price is controlled by the server; never trust an amount sent by the browser.
    const order = await razorpay.orders.create({
      amount: PRODUCT.amount,
      currency: PRODUCT.currency,
      receipt: `md-${Date.now()}`,
      notes: {
        product_id: PRODUCT.id,
        product_name: PRODUCT.name
      }
    });

    return res.status(200).json({
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: process.env.RAZORPAY_KEY_ID,
      product: PRODUCT.name
    });
  } catch (error) {
    console.error('Razorpay create-order error:', error?.error || error?.message || error);
    const status = Number(error?.statusCode) || 500;
    return res.status(status >= 400 && status < 600 ? status : 500).json({
      error: 'Unable to create Razorpay order.'
    });
  }
};
