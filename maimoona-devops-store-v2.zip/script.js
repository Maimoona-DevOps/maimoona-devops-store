const modal = document.getElementById("checkoutModal");
const toast = document.getElementById("toast");

function openCheckout(){
  modal.classList.add("show");
  modal.setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";
}
function closeCheckout(){
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden","true");
  document.body.style.overflow="";
}
function showNotice(message){
  toast.textContent=message;
  toast.classList.add("show");
  setTimeout(()=>toast.classList.remove("show"),3200);
}
modal.addEventListener("click",(e)=>{ if(e.target===modal) closeCheckout(); });
document.addEventListener("keydown",(e)=>{ if(e.key==="Escape") closeCheckout(); });
