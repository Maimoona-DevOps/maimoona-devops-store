MAIMOONA.DEVOPS — Website v2

How to run:
1. Extract this ZIP.
2. Open the folder.
3. Double-click index.html.
4. The website opens in Chrome/Edge.

Current status:
- Professional responsive storefront design
- Roadmaps: DevOps, AWS Cloud Engineer, SRE Engineer
- Featured AWS DevOps Roadmap 2026 product at ₹149
- Free resources section
- Responsive mobile layout
- Checkout is a placeholder only

NOT YET CONNECTED:
- Razorpay live/test payment gateway
- Payment verification
- Automatic eBook delivery
- Live hosting/domain

Next implementation step:
Connect Razorpay Test Mode to the BUY NOW button, then add secure post-payment eBook delivery.
